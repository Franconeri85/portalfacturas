import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'youpez-header-title',
  templateUrl: './app-header-title.component.html',
  styleUrls: ['./app-header-title.component.scss']
})
export class AppHeaderTitleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
