import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-layout-basic',
  templateUrl: './app-layout-basic.component.html',
  styleUrls: ['./app-layout-basic.component.scss']
})
export class AppLayoutBasicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
