import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-layout-divided-full',
  templateUrl: './app-layout-divided-full.component.html',
  styleUrls: ['./app-layout-divided-full.component.scss']
})
export class AppLayoutDividedFullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
