import { Component, Input, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit {

  constructor( private service: AuthService) { }

  infoUser: any;
  message: string;
  ngOnInit(): void {
    this.createUser();
  }

  createUser(){
    this.infoUser = {
      userid: localStorage.getItem('userId'),
      nombre:  localStorage.getItem('name'),
      apellido:  localStorage.getItem('surname'),
      email:  localStorage.getItem('email')
    }
    this.service.createUser(this.infoUser).subscribe(
      (response: any) =>{
        this.message = response.detalle
      },
      err => {
        this.message = err.error.detalleError
      }
    )
  }
}
