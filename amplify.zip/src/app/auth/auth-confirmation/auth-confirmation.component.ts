import {Component, OnInit} from '@angular/core'

@Component({
  selector: 'app-auth-confirmation',
  templateUrl: './auth-confirmation.component.html',
  styleUrls: ['./auth-confirmation.component.scss']
})
export class AuthConfirmationComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }

}
