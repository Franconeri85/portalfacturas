import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-right-sidebar-tabs',
  templateUrl: './starter-right-sidebar-tabs.component.html',
  styleUrls: ['./starter-right-sidebar-tabs.component.scss']
})
export class StarterRightSidebarTabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
