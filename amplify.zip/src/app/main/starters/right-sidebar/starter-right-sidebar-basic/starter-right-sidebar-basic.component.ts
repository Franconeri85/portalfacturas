import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-right-sidebar-basic',
  templateUrl: './starter-right-sidebar-basic.component.html',
  styleUrls: ['./starter-right-sidebar-basic.component.scss']
})
export class StarterRightSidebarBasicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
