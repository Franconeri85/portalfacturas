import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-left-sidebar-header',
  templateUrl: './starter-left-sidebar-header.component.html',
  styleUrls: ['./starter-left-sidebar-header.component.scss']
})
export class StarterLeftSidebarHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
