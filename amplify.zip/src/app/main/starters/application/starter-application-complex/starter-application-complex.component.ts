import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-application-complex',
  templateUrl: './starter-application-complex.component.html',
  styleUrls: ['./starter-application-complex.component.scss']
})
export class StarterApplicationComplexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
