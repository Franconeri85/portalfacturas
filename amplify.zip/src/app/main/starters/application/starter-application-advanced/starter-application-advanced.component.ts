import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-application-advanced',
  templateUrl: './starter-application-advanced.component.html',
  styleUrls: ['./starter-application-advanced.component.scss']
})
export class StarterApplicationAdvancedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
