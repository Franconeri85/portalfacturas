import {Component, OnInit} from '@angular/core'

@Component({
  selector: 'app-starter-full-width-basic',
  templateUrl: './starter-full-width-basic.component.html',
  styleUrls: ['./starter-full-width-basic.component.scss']
})
export class StarterFullWidthBasicComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }

}
