import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-full-width-header',
  templateUrl: './starter-full-width-header.component.html',
  styleUrls: ['./starter-full-width-header.component.scss']
})
export class StarterFullWidthHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
