import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing-other',
  templateUrl: './pricing-other.component.html',
  styleUrls: ['./pricing-other.component.css']
})
export class PricingOtherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
