export class EstadisticasModel{
    tiempoPromedio: string;
    cantidad: string;
}