export class FechaModel{
    dia: string;
    mes: string;
}