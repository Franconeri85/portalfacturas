export class UsuarioModel{
    name: string;
    surname: string;
    email: string;
    phone: string;
    password: string;
    company: string;
    user_type_id: string;
}