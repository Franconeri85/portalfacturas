import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-creditcard',
  templateUrl: './user-creditcard.component.html',
  styleUrls: ['./user-creditcard.component.scss']
})
export class UserCreditcardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
