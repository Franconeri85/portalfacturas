import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-billing',
  templateUrl: './user-billing.component.html',
  styleUrls: ['./user-billing.component.scss']
})
export class UserBillingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
